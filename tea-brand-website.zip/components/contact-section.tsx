"use client"

import type React from "react"

import { useSnapshot } from "valtio"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Phone, Mail, MapPin, Clock } from "lucide-react"
import { appState, actions } from "@/lib/store"

export function ContactSection() {
  const snap = useSnapshot(appState)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    // 清除之前的错误
    actions.clearContactFormErrors()

    // 简单验证
    let hasErrors = false

    if (!snap.contactForm.name.trim()) {
      actions.setContactFormError("name", "请输入姓名")
      hasErrors = true
    }

    if (!snap.contactForm.phone.trim()) {
      actions.setContactFormError("phone", "请输入联系电话")
      hasErrors = true
    }

    if (!snap.contactForm.requirements.trim()) {
      actions.setContactFormError("requirements", "请描述您的定制需求")
      hasErrors = true
    }

    if (hasErrors) return

    // 模拟提交
    actions.setSubmitting(true)

    try {
      // 这里可以添加实际的API调用
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // 提交成功，重置表单
      actions.resetContactForm()
      alert("咨询提交成功！我们会尽快与您联系。")
    } catch (error) {
      alert("提交失败，请稍后重试。")
    } finally {
      actions.setSubmitting(false)
    }
  }

  return (
    <section id="contact" className="py-20 bg-secondary/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 tea-heading">
            联系<span className="text-primary">我们</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
            开启您的专属茶品定制之旅，我们的专业团队随时为您服务
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <Card>
            <CardContent className="p-8">
              <h3 className="text-2xl font-semibold mb-6 tea-heading">立即咨询定制</h3>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">姓名 *</label>
                    <Input
                      placeholder="请输入您的姓名"
                      value={snap.contactForm.name}
                      onChange={(e) => actions.updateContactForm("name", e.target.value)}
                      className={snap.contactForm.errors.name ? "border-red-500" : ""}
                    />
                    {snap.contactForm.errors.name && (
                      <p className="text-red-500 text-sm mt-1">{snap.contactForm.errors.name}</p>
                    )}
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">电话 *</label>
                    <Input
                      placeholder="请输入您的联系电话"
                      value={snap.contactForm.phone}
                      onChange={(e) => actions.updateContactForm("phone", e.target.value)}
                      className={snap.contactForm.errors.phone ? "border-red-500" : ""}
                    />
                    {snap.contactForm.errors.phone && (
                      <p className="text-red-500 text-sm mt-1">{snap.contactForm.errors.phone}</p>
                    )}
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">邮箱</label>
                  <Input
                    type="email"
                    placeholder="请输入您的邮箱地址"
                    value={snap.contactForm.email}
                    onChange={(e) => actions.updateContactForm("email", e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">定制需求 *</label>
                  <Textarea
                    placeholder="请详细描述您的定制需求，包括茶叶类型、用途、预算等"
                    rows={4}
                    value={snap.contactForm.requirements}
                    onChange={(e) => actions.updateContactForm("requirements", e.target.value)}
                    className={snap.contactForm.errors.requirements ? "border-red-500" : ""}
                  />
                  {snap.contactForm.errors.requirements && (
                    <p className="text-red-500 text-sm mt-1">{snap.contactForm.errors.requirements}</p>
                  )}
                </div>
                <Button
                  type="submit"
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
                  disabled={snap.contactForm.isSubmitting}
                >
                  {snap.contactForm.isSubmitting ? "提交中..." : "提交咨询"}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <div className="space-y-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <Phone className="h-6 w-6 text-primary mt-1" />
                  <div>
                    <h4 className="font-semibold mb-1">联系电话</h4>
                    <p className="text-muted-foreground">400-888-8888</p>
                    <p className="text-muted-foreground">010-12345678</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <Mail className="h-6 w-6 text-primary mt-1" />
                  <div>
                    <h4 className="font-semibold mb-1">邮箱地址</h4>
                    <p className="text-muted-foreground">custom@fengmingyasong.com</p>
                    <p className="text-muted-foreground">info@fengmingyasong.com</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <MapPin className="h-6 w-6 text-primary mt-1" />
                  <div>
                    <h4 className="font-semibold mb-1">公司地址</h4>
                    <p className="text-muted-foreground">北京市朝阳区茶文化产业园</p>
                    <p className="text-muted-foreground">凤茗雅颂总部大楼</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <Clock className="h-6 w-6 text-primary mt-1" />
                  <div>
                    <h4 className="font-semibold mb-1">服务时间</h4>
                    <p className="text-muted-foreground">周一至周五：9:00 - 18:00</p>
                    <p className="text-muted-foreground">周六至周日：10:00 - 17:00</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}
