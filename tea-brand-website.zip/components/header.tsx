"use client"

import { useSnapshot } from "valtio"
import { Button } from "@/components/ui/button"
import { Menu, X } from "lucide-react"
import { appState, actions } from "@/lib/store"

export function Header() {
  const snap = useSnapshot(appState)

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-sm">凤</span>
            </div>
            <span className="text-xl font-semibold tea-heading">凤茗雅颂</span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a
              href="#home"
              className={`transition-colors ${
                snap.navigation.activeSection === "home"
                  ? "text-primary font-medium"
                  : "text-foreground hover:text-primary"
              }`}
              onClick={() => actions.setActiveSection("home")}
            >
              首页
            </a>
            <a
              href="#custom"
              className={`transition-colors ${
                snap.navigation.activeSection === "custom"
                  ? "text-primary font-medium"
                  : "text-foreground hover:text-primary"
              }`}
              onClick={() => actions.setActiveSection("custom")}
            >
              源头私定
            </a>
            <a
              href="#cases"
              className={`transition-colors ${
                snap.navigation.activeSection === "cases"
                  ? "text-primary font-medium"
                  : "text-foreground hover:text-primary"
              }`}
              onClick={() => actions.setActiveSection("cases")}
            >
              定制案例
            </a>
            <a
              href="#tea-types"
              className={`transition-colors ${
                snap.navigation.activeSection === "tea-types"
                  ? "text-primary font-medium"
                  : "text-foreground hover:text-primary"
              }`}
              onClick={() => actions.setActiveSection("tea-types")}
            >
              茶品分类
            </a>
            <a
              href="#process"
              className={`transition-colors ${
                snap.navigation.activeSection === "process"
                  ? "text-primary font-medium"
                  : "text-foreground hover:text-primary"
              }`}
              onClick={() => actions.setActiveSection("process")}
            >
              定制流程
            </a>
            <a
              href="#contact"
              className={`transition-colors ${
                snap.navigation.activeSection === "contact"
                  ? "text-primary font-medium"
                  : "text-foreground hover:text-primary"
              }`}
              onClick={() => actions.setActiveSection("contact")}
            >
              联系我们
            </a>
          </nav>

          {/* CTA Button */}
          <div className="hidden md:block">
            <Button
              className="bg-accent hover:bg-accent/90 text-accent-foreground"
              onClick={() => {
                actions.setActiveSection("contact")
                document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })
              }}
            >
              立即定制
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button className="md:hidden" onClick={actions.toggleMenu}>
            {snap.navigation.isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {snap.navigation.isMenuOpen && (
          <nav className="md:hidden mt-4 pb-4 border-t border-border pt-4">
            <div className="flex flex-col space-y-4">
              <a
                href="#home"
                className={`transition-colors ${
                  snap.navigation.activeSection === "home"
                    ? "text-primary font-medium"
                    : "text-foreground hover:text-primary"
                }`}
                onClick={() => {
                  actions.setActiveSection("home")
                  actions.closeMenu()
                }}
              >
                首页
              </a>
              <a
                href="#custom"
                className={`transition-colors ${
                  snap.navigation.activeSection === "custom"
                    ? "text-primary font-medium"
                    : "text-foreground hover:text-primary"
                }`}
                onClick={() => {
                  actions.setActiveSection("custom")
                  actions.closeMenu()
                }}
              >
                源头私定
              </a>
              <a
                href="#cases"
                className={`transition-colors ${
                  snap.navigation.activeSection === "cases"
                    ? "text-primary font-medium"
                    : "text-foreground hover:text-primary"
                }`}
                onClick={() => {
                  actions.setActiveSection("cases")
                  actions.closeMenu()
                }}
              >
                定制案例
              </a>
              <a
                href="#tea-types"
                className={`transition-colors ${
                  snap.navigation.activeSection === "tea-types"
                    ? "text-primary font-medium"
                    : "text-foreground hover:text-primary"
                }`}
                onClick={() => {
                  actions.setActiveSection("tea-types")
                  actions.closeMenu()
                }}
              >
                茶品分类
              </a>
              <a
                href="#process"
                className={`transition-colors ${
                  snap.navigation.activeSection === "process"
                    ? "text-primary font-medium"
                    : "text-foreground hover:text-primary"
                }`}
                onClick={() => {
                  actions.setActiveSection("process")
                  actions.closeMenu()
                }}
              >
                定制流程
              </a>
              <a
                href="#contact"
                className={`transition-colors ${
                  snap.navigation.activeSection === "contact"
                    ? "text-primary font-medium"
                    : "text-foreground hover:text-primary"
                }`}
                onClick={() => {
                  actions.setActiveSection("contact")
                  actions.closeMenu()
                }}
              >
                联系我们
              </a>
              <Button
                className="bg-accent hover:bg-accent/90 text-accent-foreground w-full"
                onClick={() => {
                  actions.setActiveSection("contact")
                  actions.closeMenu()
                  document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })
                }}
              >
                立即定制
              </Button>
            </div>
          </nav>
        )}
      </div>
    </header>
  )
}
