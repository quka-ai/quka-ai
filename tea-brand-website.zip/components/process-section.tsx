import { Card, CardContent } from "@/components/ui/card"
import { MessageCircle, Search, Leaf, Package, Truck, Heart } from "lucide-react"

export function ProcessSection() {
  const steps = [
    {
      icon: <MessageCircle className="h-8 w-8 text-primary" />,
      title: "需求沟通",
      description: "详细了解您的口味偏好、使用场景和特殊需求",
      details: ["口味偏好调研", "使用场景分析", "预算范围确定", "特殊要求记录"],
    },
    {
      icon: <Search className="h-8 w-8 text-primary" />,
      title: "方案设计",
      description: "根据需求设计专属茶品方案，包括茶叶选择和包装设计",
      details: ["茶叶品种选择", "配比方案设计", "包装风格确定", "价格方案制定"],
    },
    {
      icon: <Leaf className="h-8 w-8 text-primary" />,
      title: "样品制作",
      description: "制作样品供您品鉴，根据反馈调整配方",
      details: ["样品制作", "品鉴反馈", "配方调整", "最终确认"],
    },
    {
      icon: <Package className="h-8 w-8 text-primary" />,
      title: "批量生产",
      description: "确认方案后进行批量生产，严格质量控制",
      details: ["原料采购", "生产制作", "质量检测", "包装完成"],
    },
    {
      icon: <Truck className="h-8 w-8 text-primary" />,
      title: "配送交付",
      description: "安全包装，快速配送，确保茶品完好送达",
      details: ["安全包装", "物流配送", "签收确认", "配送跟踪"],
    },
    {
      icon: <Heart className="h-8 w-8 text-primary" />,
      title: "售后服务",
      description: "提供完善的售后服务，建立长期合作关系",
      details: ["使用指导", "储存建议", "定期回访", "后续定制"],
    },
  ]

  return (
    <section id="process" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 tea-heading">
            <span className="text-primary">定制流程</span>
            <br />
            专业贴心
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
            六个步骤，为您打造专属茶品。从初次沟通到最终交付， 我们的专业团队将全程为您提供贴心服务
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <Card key={index} className="relative hover:shadow-lg transition-shadow duration-300">
              <CardContent className="p-6">
                {/* Step Number */}
                <div className="absolute -top-4 -left-4 w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold text-sm">
                  {index + 1}
                </div>

                {/* Icon */}
                <div className="flex justify-center mb-4">{step.icon}</div>

                {/* Title */}
                <h3 className="text-xl font-semibold mb-3 text-center tea-heading">{step.title}</h3>

                {/* Description */}
                <p className="text-muted-foreground text-center mb-4 text-pretty">{step.description}</p>

                {/* Details */}
                <ul className="space-y-2">
                  {step.details.map((detail, detailIndex) => (
                    <li key={detailIndex} className="flex items-center text-sm text-muted-foreground">
                      <div className="w-1.5 h-1.5 bg-primary rounded-full mr-2 flex-shrink-0"></div>
                      {detail}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Timeline Connector for Desktop */}
        <div className="hidden lg:block relative mt-8">
          <div className="absolute top-1/2 left-0 right-0 h-px bg-border -translate-y-1/2"></div>
          <div className="flex justify-between items-center">
            {steps.map((_, index) => (
              <div key={index} className="w-4 h-4 bg-primary rounded-full border-4 border-background"></div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
