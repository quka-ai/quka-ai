import { Card, CardContent } from "@/components/ui/card"
import { Leaf, Mountain, Users, Award } from "lucide-react"

export function CustomSection() {
  const features = [
    {
      icon: <Mountain className="h-8 w-8 text-primary" />,
      title: "源头直采",
      description: "深入茶山原产地，与茶农直接合作，确保每一片茶叶的品质与纯正",
    },
    {
      icon: <Leaf className="h-8 w-8 text-primary" />,
      title: "个性定制",
      description: "根据您的口味偏好、饮茶习惯，量身定制专属茶品配方",
    },
    {
      icon: <Users className="h-8 w-8 text-primary" />,
      title: "专业团队",
      description: "资深茶艺师与制茶大师团队，为您提供专业的茶品定制服务",
    },
    {
      icon: <Award className="h-8 w-8 text-primary" />,
      title: "品质保证",
      description: "严格的品质控制体系，确保每一款定制茶品都达到最高标准",
    },
  ]

  return (
    <section id="custom" className="py-20 bg-secondary/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 tea-heading">
            源头私定的
            <span className="text-primary">独特优势</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
            我们不仅仅是茶叶的搬运工，更是您专属茶品的创造者。 从茶园到茶杯，每一个环节都体现着我们对品质的执着追求。
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="text-center hover:shadow-lg transition-shadow duration-300">
              <CardContent className="p-8">
                <div className="flex justify-center mb-4">{feature.icon}</div>
                <h3 className="text-xl font-semibold mb-4 tea-heading">{feature.title}</h3>
                <p className="text-muted-foreground text-pretty">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Quote Section */}
        <div className="mt-20 text-center">
          <blockquote className="text-2xl md:text-3xl font-medium text-primary mb-4 tea-script">
            "一叶一世界，一茶一人生"
          </blockquote>
          <p className="text-muted-foreground">— 凤茗雅颂创始人</p>
        </div>
      </div>
    </section>
  )
}
