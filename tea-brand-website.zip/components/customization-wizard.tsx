"use client"

import { useSnapshot } from "valtio"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { appState, actions } from "@/lib/store"
import { ChevronLeft, ChevronRight, Check } from "lucide-react"

export function CustomizationWizard() {
  const snap = useSnapshot(appState)

  if (snap.customization.customizationStep === 0) {
    return null
  }

  const handleNext = () => {
    if (snap.customization.customizationStep < 4) {
      actions.setCustomizationStep(snap.customization.customizationStep + 1)
    }
  }

  const handlePrev = () => {
    if (snap.customization.customizationStep > 1) {
      actions.setCustomizationStep(snap.customization.customizationStep - 1)
    }
  }

  const handleComplete = () => {
    actions.setActiveSection("contact")
    document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })
  }

  const renderStep = () => {
    switch (snap.customization.customizationStep) {
      case 1:
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-semibold">选择口味偏好</h3>
            <div className="grid grid-cols-2 gap-4">
              {["清淡", "浓郁", "甘甜", "回甘", "花香", "果香"].map((flavor) => (
                <Button
                  key={flavor}
                  variant={snap.customization.preferences.flavor === flavor ? "default" : "outline"}
                  onClick={() => actions.updatePreferences("flavor", flavor)}
                  className="h-12"
                >
                  {flavor}
                </Button>
              ))}
            </div>
          </div>
        )

      case 2:
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-semibold">选择包装方式</h3>
            <div className="space-y-4">
              {[
                { id: "gift", name: "礼品装", desc: "精美包装，适合送礼" },
                { id: "daily", name: "日常装", desc: "简约包装，日常饮用" },
                { id: "collection", name: "收藏装", desc: "专业包装，长期保存" },
              ].map((pkg) => (
                <Card
                  key={pkg.id}
                  className={`cursor-pointer transition-all ${
                    snap.customization.preferences.packaging === pkg.id ? "ring-2 ring-primary" : ""
                  }`}
                  onClick={() => actions.updatePreferences("packaging", pkg.id)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">{pkg.name}</h4>
                        <p className="text-sm text-muted-foreground">{pkg.desc}</p>
                      </div>
                      {snap.customization.preferences.packaging === pkg.id && (
                        <Check className="h-5 w-5 text-primary" />
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )

      case 3:
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-semibold">选择数量和预算</h3>
            <div className="space-y-4">
              <div>
                <Label>数量 (克)</Label>
                <Slider
                  value={[snap.customization.preferences.quantity]}
                  onValueChange={(value) => actions.updatePreferences("quantity", value[0])}
                  max={1000}
                  min={50}
                  step={50}
                  className="mt-2"
                />
                <p className="text-sm text-muted-foreground mt-1">{snap.customization.preferences.quantity}克</p>
              </div>
              <div>
                <Label>预算范围</Label>
                <Select
                  value={snap.customization.preferences.budget}
                  onValueChange={(value) => actions.updatePreferences("budget", value)}
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="请选择预算范围" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="100-300">100-300元</SelectItem>
                    <SelectItem value="300-500">300-500元</SelectItem>
                    <SelectItem value="500-1000">500-1000元</SelectItem>
                    <SelectItem value="1000+">1000元以上</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        )

      case 4:
        return (
          <div className="space-y-6">
            <h3 className="text-xl font-semibold">确认定制信息</h3>
            <div className="space-y-4">
              <div className="p-4 bg-muted rounded-lg">
                <h4 className="font-medium mb-2">您的定制偏好：</h4>
                <ul className="space-y-1 text-sm">
                  <li>茶类：{snap.customization.selectedTeaType}</li>
                  <li>口味：{snap.customization.preferences.flavor}</li>
                  <li>包装：{snap.customization.preferences.packaging}</li>
                  <li>数量：{snap.customization.preferences.quantity}克</li>
                  <li>预算：{snap.customization.preferences.budget}</li>
                </ul>
              </div>
              <Button onClick={handleComplete} className="w-full" size="lg">
                提交定制需求
              </Button>
            </div>
          </div>
        )

      default:
        return null
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>定制向导</span>
            <span className="text-sm font-normal">{snap.customization.customizationStep}/4</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {renderStep()}

          <div className="flex justify-between mt-8">
            <Button variant="outline" onClick={handlePrev} disabled={snap.customization.customizationStep === 1}>
              <ChevronLeft className="h-4 w-4 mr-1" />
              上一步
            </Button>

            {snap.customization.customizationStep < 4 ? (
              <Button onClick={handleNext}>
                下一步
                <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            ) : (
              <Button onClick={() => actions.resetCustomization()} variant="outline">
                关闭
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
