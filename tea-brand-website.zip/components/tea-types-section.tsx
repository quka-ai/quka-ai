"use client"

import { useSnapshot } from "valtio"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { appState, actions } from "@/lib/store"

export function TeaTypesSection() {
  const snap = useSnapshot(appState)

  const teaTypes = [
    {
      id: "green",
      name: "绿茶系列",
      description: "清香淡雅，回甘悠长",
      varieties: ["西湖龙井", "碧螺春", "黄山毛峰", "信阳毛尖"],
      image: "/fresh-green-tea-leaves-in-traditional-chinese-tea-.jpg",
      color: "bg-green-50 border-green-200",
    },
    {
      id: "black",
      name: "红茶系列",
      description: "醇厚甘甜，温润如玉",
      varieties: ["正山小种", "祁门红茶", "滇红", "英德红茶"],
      image: "/rich-black-tea-leaves-with-golden-tips.jpg",
      color: "bg-red-50 border-red-200",
    },
    {
      id: "oolong",
      name: "乌龙茶系列",
      description: "半发酵工艺，香韵独特",
      varieties: ["铁观音", "大红袍", "凤凰单丛", "台湾高山茶"],
      image: "/oolong-tea-leaves-with-traditional-chinese-tea-cer.jpg",
      color: "bg-amber-50 border-amber-200",
    },
    {
      id: "puer",
      name: "普洱茶系列",
      description: "越陈越香，收藏佳品",
      varieties: ["生普洱", "熟普洱", "古树茶", "宫廷普洱"],
      image: "/aged-pu-erh-tea-cake-with-traditional-chinese-char.jpg",
      color: "bg-stone-50 border-stone-200",
    },
    {
      id: "white",
      name: "白茶系列",
      description: "自然萎凋，清淡甘甜",
      varieties: ["白毫银针", "白牡丹", "寿眉", "贡眉"],
      image: "/delicate-white-tea-buds-with-silver-hairs.jpg",
      color: "bg-gray-50 border-gray-200",
    },
    {
      id: "floral",
      name: "花茶系列",
      description: "花香茶韵，养生佳品",
      varieties: ["茉莉花茶", "玫瑰花茶", "桂花乌龙", "薰衣草茶"],
      image: "/floral-tea-blend-with-dried-flowers-and-tea-leaves.jpg",
      color: "bg-purple-50 border-purple-200",
    },
  ]

  const handleTeaSelection = (teaId: string, teaName: string) => {
    actions.setSelectedTeaType(teaId)
    actions.setCustomizationStep(1)
    // 滚动到联系区域
    document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <section id="tea-types" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 tea-heading">
            <span className="text-primary">六大茶类</span>
            <br />
            任您选择
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
            传承千年的中国茶文化，六大茶类各具特色，我们为您提供最优质的茶叶原料， 根据您的喜好进行个性化定制
          </p>
          {snap.customization.selectedTeaType && (
            <div className="mt-4 p-3 bg-primary/10 rounded-lg inline-block">
              <p className="text-primary font-medium">
                已选择：{teaTypes.find((t) => t.id === snap.customization.selectedTeaType)?.name}
              </p>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {teaTypes.map((tea, index) => (
            <Card
              key={index}
              className={`overflow-hidden hover:shadow-lg transition-all duration-300 cursor-pointer ${tea.color} ${
                snap.customization.selectedTeaType === tea.id ? "ring-2 ring-primary" : ""
              }`}
              onClick={() => handleTeaSelection(tea.id, tea.name)}
            >
              <div className="aspect-[4/3] overflow-hidden">
                <img
                  src={tea.image || "/placeholder.svg"}
                  alt={tea.name}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold mb-2 tea-heading">{tea.name}</h3>
                <p className="text-muted-foreground mb-4 text-pretty">{tea.description}</p>
                <div className="space-y-2 mb-4">
                  <p className="text-sm font-medium text-foreground">主要品种：</p>
                  <div className="flex flex-wrap gap-2">
                    {tea.varieties.map((variety, varietyIndex) => (
                      <span
                        key={varietyIndex}
                        className="px-2 py-1 bg-background text-foreground text-xs rounded border"
                      >
                        {variety}
                      </span>
                    ))}
                  </div>
                </div>
                <Button
                  className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
                  onClick={(e) => {
                    e.stopPropagation()
                    handleTeaSelection(tea.id, tea.name)
                  }}
                >
                  {snap.customization.selectedTeaType === tea.id ? "已选择此茶类" : "选择定制"}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
