export function Footer() {
  return (
    <footer className="bg-foreground text-background py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-background text-foreground rounded-full flex items-center justify-center">
                <span className="font-bold text-sm">凤</span>
              </div>
              <span className="text-xl font-semibold tea-heading">凤茗雅颂</span>
            </div>
            <p className="text-background/80 mb-4 max-w-md text-pretty">
              专注于源头私人定制的高端茶品牌，传承千年茶文化， 为每一位茶友提供专属定制服务。
            </p>
            <p className="text-background/60 text-sm">© 2025 凤茗雅颂. 保留所有权利.</p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-4">快速链接</h4>
            <ul className="space-y-2 text-background/80">
              <li>
                <a href="#home" className="hover:text-background transition-colors">
                  首页
                </a>
              </li>
              <li>
                <a href="#custom" className="hover:text-background transition-colors">
                  源头私定
                </a>
              </li>
              <li>
                <a href="#cases" className="hover:text-background transition-colors">
                  定制案例
                </a>
              </li>
              <li>
                <a href="#tea-types" className="hover:text-background transition-colors">
                  茶品分类
                </a>
              </li>
              <li>
                <a href="#process" className="hover:text-background transition-colors">
                  定制流程
                </a>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-semibold mb-4">联系方式</h4>
            <ul className="space-y-2 text-background/80 text-sm">
              <li>电话：400-888-8888</li>
              <li>邮箱：info@fengmingyasong.com</li>
              <li>地址：北京市朝阳区茶文化产业园</li>
              <li>微信：凤茗雅颂官方</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-background/20 mt-8 pt-8 text-center">
          <p className="text-background/60 text-sm">京ICP备12345678号 | 食品经营许可证：JY12345678901234567890</p>
        </div>
      </div>
    </footer>
  )
}
