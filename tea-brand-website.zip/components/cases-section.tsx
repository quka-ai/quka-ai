import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export function CasesSection() {
  const cases = [
    {
      title: "企业定制礼品茶",
      client: "某知名科技公司",
      description: "为企业年会定制的专属礼品茶，融合公司文化元素，包装设计独特",
      image: "/elegant-corporate-gift-tea-packaging-with-modern-d.jpg",
      tags: ["企业定制", "礼品茶", "包装设计"],
    },
    {
      title: "婚庆纪念茶",
      client: "新人夫妇",
      description: "为新婚夫妇定制的纪念茶，选用优质大红袍，包装融入婚礼主题色彩",
      image: "/wedding-commemorative-tea-with-elegant-red-and-gol.jpg",
      tags: ["婚庆定制", "纪念茶", "大红袍"],
    },
    {
      title: "私人收藏级普洱",
      client: "茶叶收藏家",
      description: "为资深茶友定制的收藏级普洱茶，精选古树茶料，传统工艺制作",
      image: "/premium-aged-pu-erh-tea-cake-with-traditional-chin.jpg",
      tags: ["私人定制", "普洱茶", "收藏级"],
    },
    {
      title: "健康养生茶",
      client: "养生爱好者",
      description: "根据客户体质特点，调配的个性化养生茶，兼顾口感与功效",
      image: "/herbal-wellness-tea-blend-with-natural-ingredients.jpg",
      tags: ["养生茶", "个性调配", "健康"],
    },
  ]

  return (
    <section id="cases" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 tea-heading">
            定制<span className="text-primary">案例展示</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
            每一个定制案例都是独一无二的故事，见证着我们与客户共同创造的美好时光
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {cases.map((case_, index) => (
            <Card key={index} className="overflow-hidden hover:shadow-xl transition-shadow duration-300">
              <div className="aspect-video overflow-hidden">
                <img
                  src={case_.image || "/placeholder.svg"}
                  alt={case_.title}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
              <CardContent className="p-6">
                <div className="flex flex-wrap gap-2 mb-3">
                  {case_.tags.map((tag, tagIndex) => (
                    <span key={tagIndex} className="px-3 py-1 bg-primary/10 text-primary text-sm rounded-full">
                      {tag}
                    </span>
                  ))}
                </div>
                <h3 className="text-xl font-semibold mb-2 tea-heading">{case_.title}</h3>
                <p className="text-sm text-accent mb-3">{case_.client}</p>
                <p className="text-muted-foreground text-pretty">{case_.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center">
          <Button variant="outline" size="lg">
            查看更多案例
          </Button>
        </div>
      </div>
    </section>
  )
}
