"use client"

import { useSnapshot } from "valtio"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"
import { appState, actions } from "@/lib/store"

export function HeroSection() {
  const snap = useSnapshot(appState)

  const handleStartCustomization = () => {
    actions.setCustomizationStep(1)
    actions.setActiveSection("tea-types")
    document.getElementById("tea-types")?.scrollIntoView({ behavior: "smooth" })
  }

  const handleLearnMore = () => {
    actions.setActiveSection("custom")
    document.getElementById("custom")?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src="/elegant-tea-plantation-with-misty-mountains-and-tr.jpg"
          alt="Tea plantation background"
          className="w-full h-full object-cover opacity-20"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/50 to-background/80" />
      </div>

      <div className="container mx-auto px-4 text-center relative z-10">
        <div className="max-w-4xl mx-auto">
          {/* Main Heading */}
          <h1 className="text-5xl md:text-7xl font-bold mb-6 tea-heading text-balance">
            源头私定
            <br />
            <span className="text-primary">传承千年茶韵</span>
          </h1>

          {/* Subtitle */}
          <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-2xl mx-auto text-pretty">
            凤茗雅颂致力于为每一位茶友提供专属定制服务， 从茶园源头到您的茶杯，每一片茶叶都承载着匠心与传承
          </p>

          {/* Progress Indicator */}
          {snap.customization.customizationStep > 0 && (
            <div className="mb-6 p-4 bg-primary/10 rounded-lg inline-block">
              <p className="text-primary font-medium">
                定制进度：第 {snap.customization.customizationStep} 步
                {snap.customization.selectedTeaType && <span className="ml-2">- 已选择茶类</span>}
              </p>
            </div>
          )}

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button
              size="lg"
              className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-4 text-lg"
              onClick={handleStartCustomization}
            >
              开始定制之旅
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            <Button variant="outline" size="lg" className="px-8 py-4 text-lg bg-transparent" onClick={handleLearnMore}>
              了解我们的故事
            </Button>
          </div>

          {/* Decorative Elements */}
          <div className="mt-16 flex justify-center items-center space-x-8 opacity-60">
            <div className="w-16 h-px bg-border"></div>
            <span className="tea-script text-2xl text-muted-foreground">茶道</span>
            <div className="w-16 h-px bg-border"></div>
          </div>
        </div>
      </div>
    </section>
  )
}
