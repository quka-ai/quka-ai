import { proxy } from "valtio"

// 联系表单状态
export interface ContactFormState {
  name: string
  phone: string
  email: string
  requirements: string
  isSubmitting: boolean
  errors: Record<string, string>
}

// 导航状态
export interface NavigationState {
  isMenuOpen: boolean
  activeSection: string
}

// 定制流程状态
export interface CustomizationState {
  selectedTeaType: string
  customizationStep: number
  preferences: {
    flavor: string
    packaging: string
    quantity: number
    budget: string
  }
}

// 全局应用状态
export interface AppState {
  navigation: NavigationState
  contactForm: ContactFormState
  customization: CustomizationState
}

// 创建全局状态
export const appState = proxy<AppState>({
  navigation: {
    isMenuOpen: false,
    activeSection: "home",
  },
  contactForm: {
    name: "",
    phone: "",
    email: "",
    requirements: "",
    isSubmitting: false,
    errors: {},
  },
  customization: {
    selectedTeaType: "",
    customizationStep: 0,
    preferences: {
      flavor: "",
      packaging: "",
      quantity: 0,
      budget: "",
    },
  },
})

// 状态操作函数
export const actions = {
  // 导航操作
  toggleMenu: () => {
    appState.navigation.isMenuOpen = !appState.navigation.isMenuOpen
  },
  closeMenu: () => {
    appState.navigation.isMenuOpen = false
  },
  setActiveSection: (section: string) => {
    appState.navigation.activeSection = section
  },

  // 联系表单操作
  updateContactForm: (field: keyof ContactFormState, value: string) => {
    if (field in appState.contactForm && typeof appState.contactForm[field] === "string") {
      ;(appState.contactForm as any)[field] = value
    }
  },
  setContactFormError: (field: string, error: string) => {
    appState.contactForm.errors[field] = error
  },
  clearContactFormErrors: () => {
    appState.contactForm.errors = {}
  },
  setSubmitting: (isSubmitting: boolean) => {
    appState.contactForm.isSubmitting = isSubmitting
  },
  resetContactForm: () => {
    appState.contactForm = {
      name: "",
      phone: "",
      email: "",
      requirements: "",
      isSubmitting: false,
      errors: {},
    }
  },

  // 定制流程操作
  setSelectedTeaType: (teaType: string) => {
    appState.customization.selectedTeaType = teaType
  },
  setCustomizationStep: (step: number) => {
    appState.customization.customizationStep = step
  },
  updatePreferences: (field: keyof CustomizationState["preferences"], value: string | number) => {
    ;(appState.customization.preferences as any)[field] = value
  },
  resetCustomization: () => {
    appState.customization = {
      selectedTeaType: "",
      customizationStep: 0,
      preferences: {
        flavor: "",
        packaging: "",
        quantity: 0,
        budget: "",
      },
    }
  },
}
