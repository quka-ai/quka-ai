import { Header } from "@/components/header"
import { HeroSection } from "@/components/hero-section"
import { CustomSection } from "@/components/custom-section"
import { CasesSection } from "@/components/cases-section"
import { TeaTypesSection } from "@/components/tea-types-section"
import { ProcessSection } from "@/components/process-section"
import { ContactSection } from "@/components/contact-section"
import { Footer } from "@/components/footer"
import { CustomizationWizard } from "@/components/customization-wizard"

export default function HomePage() {
  return (
    <main className="min-h-screen">
      <Header />
      <HeroSection />
      <CustomSection />
      <CasesSection />
      <TeaTypesSection />
      <ProcessSection />
      <ContactSection />
      <Footer />
      <CustomizationWizard />
    </main>
  )
}
